# Treasury Pulse — Frontend

AI-powered short-term liquidity manager. React + Vite + Tailwind + Recharts. Frontend only, runs on demo data.

## Run
```bash
npm install
npm run dev
```
Open the URL Vite prints. Pick a role on the login screen (demo access only). The role selector in the top bar switches between Analyst, Treasury Manager and Admin.

## Backend integration
- All data access lives in `src/services/api.js`. Replace the mock return values with real requests. Set `VITE_API_BASE_URL` in a `.env` file.
- Demo data and role policy: `src/data/mock.js` (`PERMISSIONS`, `DEFAULT_THRESHOLDS`, entities, alerts).
- CSV upload: `uploadTransactionsCsv(file)` in `api.js` is ready for multipart/form-data.

## AI chatbot (floating widget, bottom-right)
- UI: `src/components/ChatWidget.jsx` (also reused on the AI Assistant page)
- State: `src/hooks/useChat.js`
- **Integration point: `askAssistant({ message, history, context })` in `src/services/api.js`.** Return `{ reply: string }`. `context` carries the current role and page.

## Currency rule
Amounts stay in their own currency. Only totals labelled "USD equivalent" use the demo FX table in `mock.js`.
