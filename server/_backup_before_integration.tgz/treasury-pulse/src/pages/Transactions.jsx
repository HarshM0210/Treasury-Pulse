import { useMemo, useRef, useState } from 'react'
import { AlertCircle, CheckCircle2, ChevronLeft, ChevronRight, FileSpreadsheet, Search, UploadCloud } from 'lucide-react'
import { uploadTransactionsCsv } from '../services/api'
import { CURRENCIES, ENTITIES, TRANSACTIONS, money } from '../data/mock'
import { Card, DemoTag, Notice, PageHeader, Select, StatusBadge } from '../components/ui'

const PAGE_SIZE = 10

function CsvUpload() {
  const inputRef = useRef(null)
  const [file, setFile] = useState(null)
  const [state, setState] = useState('idle') // idle | selected | error
  const [drag, setDrag] = useState(false)

  const pick = async (f) => {
    if (!f) return
    if (!f.name.toLowerCase().endsWith('.csv')) {
      setFile(null)
      setState('error')
      return
    }
    setFile(f)
    setState('selected')
    // Wired to the service layer so multipart upload can be added in one place later.
    await uploadTransactionsCsv(f)
  }

  return (
    <Card title="Upload transactions (CSV)" subtitle="Bring in settled and expected transactions for forecasting">
      <div className="grid gap-4 lg:grid-cols-2">
        <div
          onDragOver={(e) => { e.preventDefault(); setDrag(true) }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files?.[0]) }}
          className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-8 text-center ${drag ? 'border-brand bg-brand-soft' : 'border-line bg-surface/60'}`}
        >
          <UploadCloud size={32} className="text-brand" />
          <p className="mt-2 text-sm font-bold">Drag and drop your CSV file here</p>
          <p className="my-1 text-xs text-muted">or</p>
          <button className="btn-primary" onClick={() => inputRef.current?.click()}>Browse files</button>
          <input ref={inputRef} type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
          <p className="mt-3 text-xs text-muted">Supported format: CSV</p>
        </div>

        <div>
          <p className="label">Upload status</p>
          {state === 'idle' && <Notice tone="blue" icon={FileSpreadsheet}>No file selected yet.</Notice>}
          {state === 'selected' && file && (
            <div className="space-y-2">
              <Notice tone="green" icon={CheckCircle2}><span className="font-semibold">{file.name}</span> selected ({(file.size / 1024).toFixed(1)} KB).</Notice>
              <Notice tone="amber" icon={AlertCircle}>The file has not been parsed, validated or sent to a server. Validation results will appear here once the backend is connected.</Notice>
            </div>
          )}
          {state === 'error' && <Notice tone="red" icon={AlertCircle}>That file is not a CSV. Choose a file ending in .csv.</Notice>}
          <div className="mt-3 rounded-lg border border-line p-3.5">
            <p className="text-xs font-bold">Validation summary</p>
            <p className="mt-1 text-xs text-muted">Valid, skipped and failed record counts will be shown here after server-side validation.</p>
          </div>
        </div>
      </div>
    </Card>
  )
}

export default function Transactions() {
  const [q, setQ] = useState('')
  const [entity, setEntity] = useState('All Entities')
  const [ccy, setCcy] = useState('All Currencies')
  const [status, setStatus] = useState('All Statuses')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [page, setPage] = useState(1)

  const rows = useMemo(() => {
    const s = q.trim().toLowerCase()
    return TRANSACTIONS.filter((t) =>
      (!s || [t.id, t.entity, t.counterparty].some((v) => v.toLowerCase().includes(s))) &&
      (entity === 'All Entities' || t.entity === entity) &&
      (ccy === 'All Currencies' || t.currency === ccy) &&
      (status === 'All Statuses' || t.status === status) &&
      (!from || t.actualDate >= from) && (!to || t.actualDate <= to)
    )
  }, [q, entity, ccy, status, from, to])

  const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))
  const current = Math.min(page, pages)
  const slice = rows.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE)
  const reset = (setter) => (v) => { setter(v); setPage(1) }

  return (
    <div className="space-y-4">
      <PageHeader title="Transactions" description="Upload transaction data and review settlement status across entities."><DemoTag /></PageHeader>
      <CsvUpload />
      <Card title="Transaction list" pad={false}>
        <div className="grid gap-3 px-5 pb-3 pt-4 sm:grid-cols-2 lg:grid-cols-6">
          <label className="relative sm:col-span-2">
            <span className="sr-only">Search</span>
            <Search size={15} className="absolute left-3 top-3 text-muted" />
            <input className="input pl-9" placeholder="Search ID, entity or counterparty" value={q} onChange={(e) => reset(setQ)(e.target.value)} />
          </label>
          <Select value={entity} onChange={reset(setEntity)} options={['All Entities', ...ENTITIES.map((e) => e.id)]} />
          <Select value={ccy} onChange={reset(setCcy)} options={['All Currencies', ...CURRENCIES]} />
          <Select value={status} onChange={reset(setStatus)} options={['All Statuses', 'Settled', 'Pending', 'Overdue', 'Failed']} />
          <div className="flex items-center gap-1.5">
            <input type="date" aria-label="From date" className="input !px-2" value={from} onChange={(e) => reset(setFrom)(e.target.value)} />
            <input type="date" aria-label="To date" className="input !px-2" value={to} onChange={(e) => reset(setTo)(e.target.value)} />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr>{['Transaction ID', 'Date (actual)', 'Due date (expected)', 'Entity', 'Counterparty', 'Amount', 'Currency', 'Direction', 'Status'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>
              {slice.map((t) => (
                <tr key={t.id} className="hover:bg-surface">
                  <td className="td font-semibold">{t.id}</td><td className="td">{t.actualDate}</td><td className="td">{t.dueDate}</td>
                  <td className="td">{t.entity}</td><td className="td">{t.counterparty}</td>
                  <td className="td text-right tabular-nums">{money(t.amount, t.currency)}</td><td className="td">{t.currency}</td>
                  <td className="td"><StatusBadge status={t.direction} /></td><td className="td"><StatusBadge status={t.status} /></td>
                </tr>
              ))}
              {slice.length === 0 && <tr><td colSpan={9} className="td py-10 text-center text-muted">No transactions match these filters. Clear a filter to see more.</td></tr>}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-line px-5 py-3 text-sm">
          <span className="text-muted">{rows.length} transactions · page {current} of {pages}</span>
          <div className="flex gap-1.5">
            <button className="btn-outline !p-2" disabled={current === 1} onClick={() => setPage(current - 1)} aria-label="Previous page"><ChevronLeft size={16} /></button>
            <button className="btn-outline !p-2" disabled={current === pages} onClick={() => setPage(current + 1)} aria-label="Next page"><ChevronRight size={16} /></button>
          </div>
        </div>
      </Card>
    </div>
  )
}
