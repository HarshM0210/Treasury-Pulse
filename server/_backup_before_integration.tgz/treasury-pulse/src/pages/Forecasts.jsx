import { useMemo, useState } from 'react'
import { Area, CartesianGrid, ComposedChart, Legend, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useThresholds } from '../context/ThresholdContext'
import { compact, entitySeries, money, signedMoney, todayKey, withThresholds } from '../data/mock'
import { Card, chartTooltipStyle, DemoTag, KpiCard, Notice, PageHeader, Select } from '../components/ui'
import { Info } from 'lucide-react'

export default function Forecasts() {
  const { thresholds } = useThresholds()
  const entities = useMemo(() => withThresholds(thresholds), [thresholds])
  const [id, setId] = useState('EU01')
  const [horizon, setHorizon] = useState('Next 30 days')
  const e = entities.find((x) => x.id === id)
  const data = useMemo(() => entitySeries(e), [e])
  const lowest = Math.min(...data.filter((d) => d.forecast != null).map((d) => d.band?.[0] ?? d.forecast))

  return (
    <div className="space-y-4">
      <PageHeader title="Forecasts" description="30-day cash balance forecast per entity, with a confidence range and the minimum cash threshold.">
        <DemoTag />
        <Select className="w-52" value={id} onChange={setId} options={entities.map((x) => ({ value: x.id, label: `${x.id} · ${x.currency}` }))} />
        <Select className="w-40" value={horizon} onChange={setHorizon} options={['Next 7 days', 'Next 14 days', 'Next 30 days']} />
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Current balance" value={money(e.balance, e.currency)} />
        <KpiCard label="30-day projected" value={money(e.projected, e.currency)} icon={undefined} />
        <KpiCard label="Minimum threshold" value={money(e.threshold, e.currency)} accent="amber" />
        <KpiCard label="Expected gap" value={signedMoney(e.gap, e.currency)} noteTone={e.gap < 0 ? 'red' : 'green'} note={e.gap < 0 ? 'Below threshold' : 'Above threshold'} />
      </div>

      <Card title={`30-day balance forecast · ${e.id} (${e.currency})`} subtitle={`${e.name} · amounts in ${e.currency}`}>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="#E3E9F2" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748B' }} interval={7} tickLine={false} />
              <YAxis tickFormatter={(v) => compact(v)} tick={{ fontSize: 11, fill: '#64748B' }} width={56} tickLine={false} axisLine={false} domain={['auto', 'auto']} />
              <Tooltip {...chartTooltipStyle} formatter={(v, n) => (Array.isArray(v) ? [`${money(v[0], e.currency)} – ${money(v[1], e.currency)}`, n] : [money(v, e.currency), n])} />
              <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />
              <Area dataKey="band" name="Confidence range" stroke="none" fill="#3478F6" fillOpacity={0.14} />
              <Line dataKey="actual" name="Historical" stroke="#3478F6" strokeWidth={2.25} dot={false} />
              <Line dataKey="forecast" name="Forecast" stroke="#7C6BD6" strokeWidth={2.25} strokeDasharray="6 4" dot={false} />
              <ReferenceLine y={e.threshold} stroke="#DC2626" strokeDasharray="4 4" label={{ value: 'Threshold', fontSize: 11, fill: '#DC2626', position: 'insideTopRight' }} />
              <ReferenceLine x={todayKey} stroke="#94A3B8" label={{ value: 'Today', fontSize: 11, fill: '#64748B', position: 'top' }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        {lowest < e.threshold && (
          <div className="mt-3"><Notice tone="red" icon={Info}>The lower end of the confidence range falls below the {e.currency} threshold. Consider running a what-if scenario.</Notice></div>
        )}
      </Card>
    </div>
  )
}
