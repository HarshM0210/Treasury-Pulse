import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AlertOctagon } from 'lucide-react'
import { useThresholds } from '../context/ThresholdContext'
import { ALERTS, CURRENCIES, alertLevel, money, signedMoney, withThresholds } from '../data/mock'
import { Card, DemoTag, KpiCard, Notice, PageHeader, Select, StatusBadge, Tabs } from '../components/ui'

export default function RiskAlerts() {
  const navigate = useNavigate()
  const { thresholds } = useThresholds()
  const [tab, setTab] = useState('Alerts')
  const [sev, setSev] = useState('All Severities')
  const [ccy, setCcy] = useState('All Currencies')
  const [selectedId, setSelectedId] = useState(ALERTS[0].id)
  const [resolved, setResolved] = useState({})

  const alerts = useMemo(() => ALERTS.map((a) => ({ ...a, status: resolved[a.id] ? 'Resolved' : a.status })), [resolved])
  const filtered = alerts.filter((a) => (sev === 'All Severities' || a.severity === sev.toLowerCase()) && (ccy === 'All Currencies' || a.currency === ccy))
  const selected = alerts.find((a) => a.id === selectedId) || alerts[0]
  const open = alerts.filter((a) => a.status === 'Open')
  const count = (s) => open.filter((a) => a.severity === s).length
  const topAlert = open.find((a) => a.severity === 'emergency')

  const live = withThresholds(thresholds).map((e) => ({ ...e, level: alertLevel(e.projected, e.threshold) }))

  return (
    <div className="space-y-4">
      <PageHeader title="Risk & alerts" description="Hourly gap checks against each currency's minimum cash threshold.">
        <DemoTag />
        <Select className="w-40" value={sev} onChange={setSev} options={['All Severities', 'Warning', 'Critical', 'Emergency']} />
        <Select className="w-40" value={ccy} onChange={setCcy} options={['All Currencies', ...CURRENCIES]} />
      </PageHeader>

      {topAlert && (
        <Notice tone="red" icon={AlertOctagon}>
          <span className="font-bold">Emergency:</span> {topAlert.entity} is projected at {money(topAlert.projected, topAlert.currency)}, below its {money(topAlert.threshold, topAlert.currency)} threshold.
        </Notice>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Open alerts" value={open.length} />
        <KpiCard label="Emergency" value={count('emergency')} accent="red" noteTone="red" />
        <KpiCard label="Critical" value={count('critical')} accent="red" />
        <KpiCard label="Warning" value={count('warning')} accent="amber" />
      </div>

      <Tabs tabs={['Alerts', 'Alert matrix', 'History']} value={tab} onChange={setTab} />

      {tab === 'Alerts' && (
        <div className="grid gap-4 xl:grid-cols-3">
          <Card title="Alert list" className="xl:col-span-2" pad={false}>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full">
                <thead><tr>{['Time', 'Entity', 'Currency', 'Projected', 'Threshold', 'Gap', 'Severity', 'Status'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
                <tbody>
                  {filtered.map((a) => (
                    <tr key={a.id} onClick={() => setSelectedId(a.id)} className={`cursor-pointer hover:bg-surface ${a.id === selected.id ? 'bg-brand-soft/50' : ''}`}>
                      <td className="td">{a.time}</td><td className="td font-semibold">{a.entity}</td><td className="td">{a.currency}</td>
                      <td className="td tabular-nums">{money(a.projected, a.currency)}</td><td className="td tabular-nums text-muted">{money(a.threshold, a.currency)}</td>
                      <td className={`td font-semibold tabular-nums ${a.projected < a.threshold ? 'text-crit' : 'text-ok'}`}>{signedMoney(a.projected - a.threshold, a.currency)}</td>
                      <td className="td"><StatusBadge status={a.severity} /></td><td className="td"><StatusBadge status={a.status} /></td>
                    </tr>
                  ))}
                  {filtered.length === 0 && <tr><td colSpan={8} className="td py-10 text-center text-muted">No alerts match these filters.</td></tr>}
                </tbody>
              </table>
            </div>
          </Card>

          <Card title="Alert details">
            <div className="mb-3 flex items-center justify-between"><p className="text-sm font-bold">{selected.title}</p><StatusBadge status={selected.severity} /></div>
            <dl className="space-y-2 text-sm">
              {[['Entity', selected.entity], ['Currency', selected.currency], ['Projected position', money(selected.projected, selected.currency)], ['Threshold', money(selected.threshold, selected.currency)], ['Liquidity gap', signedMoney(selected.projected - selected.threshold, selected.currency)], ['Expected date', selected.expected]].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3 border-b border-line pb-2"><dt className="text-muted">{k}</dt><dd className="font-semibold tabular-nums">{v}</dd></div>
              ))}
            </dl>
            <div className="mt-4 flex flex-col gap-2">
              <button className="btn-primary" onClick={() => navigate('/transactions')}>View supporting transactions</button>
              <button className="btn-outline" onClick={() => navigate('/what-if')}>Test a scenario</button>
              {selected.status === 'Open' && <button className="btn-outline" onClick={() => setResolved({ ...resolved, [selected.id]: true })}>Mark as resolved</button>}
            </div>
          </Card>
        </div>
      )}

      {tab === 'Alert matrix' && (
        <Card title="Alert matrix" subtitle="Per-entity, per-currency evaluation against the configured threshold" pad={false}>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full">
              <thead><tr>{['Entity', 'Region', 'Currency', 'Threshold', 'Projected', 'Gap', 'Alert level'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
              <tbody>
                {live.map((e) => (
                  <tr key={e.id}>
                    <td className="td font-semibold">{e.id}</td><td className="td">{e.region}</td><td className="td">{e.currency}</td>
                    <td className="td tabular-nums">{money(e.threshold, e.currency)}</td><td className="td tabular-nums">{money(e.projected, e.currency)}</td>
                    <td className={`td font-semibold tabular-nums ${e.gap < 0 ? 'text-crit' : 'text-ok'}`}>{signedMoney(e.gap, e.currency)}</td>
                    <td className="td">{e.level ? <StatusBadge status={e.level} /> : <StatusBadge status="surplus" />}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="grid gap-2 px-5 py-4 text-xs text-muted sm:grid-cols-3">
            <p><b className="text-warn">Warning:</b> within 5–10% of threshold</p>
            <p><b className="text-crit">Critical:</b> within 0–5% of threshold</p>
            <p><b className="text-crit">Emergency:</b> below threshold or negative</p>
          </div>
        </Card>
      )}

      {tab === 'History' && (
        <Card title="Alert history" subtitle="Timestamp, severity and resolution status" pad={false}>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full">
              <thead><tr>{['ID', 'Time', 'Entity', 'Description', 'Severity', 'Resolution'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
              <tbody>
                {alerts.map((a) => (
                  <tr key={a.id}><td className="td font-semibold">{a.id}</td><td className="td">{a.time}</td><td className="td">{a.entity}</td><td className="td">{a.title}</td><td className="td"><StatusBadge status={a.severity} /></td><td className="td"><StatusBadge status={a.status} /></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}
