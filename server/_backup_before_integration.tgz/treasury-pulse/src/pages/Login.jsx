import { useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Landmark } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { ROLES } from '../data/mock'
import { Notice } from '../components/ui'

const ROLE_NOTE = {
  Analyst: 'Entity-level data, what-if analysis, personal reports',
  'Treasury Manager': 'Regional aggregates, drill-down, approvals',
  Admin: 'Full access, users, thresholds, report scheduler',
}

function Globe() {
  // Simple network-globe illustration
  const nodes = [[110, 90], [200, 60], [270, 120], [160, 170], [90, 200], [250, 220], [190, 250]]
  return (
    <svg viewBox="0 0 360 320" className="mx-auto w-full max-w-[340px]" aria-hidden>
      <defs>
        <radialGradient id="g" cx="40%" cy="35%">
          <stop offset="0%" stopColor="#3478F6" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#101C2D" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="180" cy="160" r="130" fill="url(#g)" />
      <g fill="none" stroke="#3478F6" strokeOpacity="0.45">
        <circle cx="180" cy="160" r="130" />
        <ellipse cx="180" cy="160" rx="55" ry="130" />
        <ellipse cx="180" cy="160" rx="100" ry="130" />
        <path d="M50 160h260M70 100h220M70 220h220" />
      </g>
      <g stroke="#7FB0FF" strokeOpacity="0.7">
        {nodes.slice(1).map((n, i) => <line key={i} x1={nodes[i][0]} y1={nodes[i][1]} x2={n[0]} y2={n[1]} />)}
      </g>
      {nodes.map(([x, y], i) => <circle key={i} cx={x} cy={y} r="4" fill="#9CC4FF" />)}
    </svg>
  )
}

export default function Login() {
  const { signedIn, signIn } = useAuth()
  const navigate = useNavigate()
  const [role, setRole] = useState('Analyst')
  const [show, setShow] = useState(false)

  if (signedIn) return <Navigate to="/overview" replace />

  const submit = (e) => {
    e.preventDefault()
    signIn(role)
    navigate('/overview')
  }

  return (
    <div className="grid min-h-full lg:grid-cols-[1.05fr_1fr]">
      <div className="hidden flex-col justify-between bg-navy p-10 text-white lg:flex">
        <div className="flex items-center gap-2.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand"><Landmark size={20} /></span>
          <span className="font-heading text-lg font-extrabold">Treasury Pulse</span>
        </div>
        <div>
          <Globe />
          <h1 className="mt-6 text-center text-4xl font-extrabold tracking-tight">Treasury Pulse</h1>
          <p className="mt-2 text-center text-lg text-slate-300">AI-powered short-term liquidity manager</p>
        </div>
        <p className="text-center text-sm text-slate-400">Global visibility &nbsp;•&nbsp; Predictive intelligence &nbsp;•&nbsp; Proactive decisions</p>
      </div>

      <div className="flex items-center justify-center bg-white p-6 sm:p-10">
        <form onSubmit={submit} className="w-full max-w-sm">
          <div className="mb-6 flex items-center gap-2 lg:hidden">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy text-white"><Landmark size={18} /></span>
            <span className="font-heading text-lg font-extrabold">Treasury Pulse</span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight">Welcome back</h2>
          <p className="mb-6 mt-1 text-sm text-muted">Sign in to your account</p>

          <label className="label" htmlFor="email">Email</label>
          <input id="email" type="email" className="input mb-4" placeholder="you@company.com" />
          <label className="label" htmlFor="pw">Password</label>
          <div className="relative mb-3">
            <input id="pw" type={show ? 'text' : 'password'} className="input pr-10" placeholder="Enter password" />
            <button type="button" onClick={() => setShow(!show)} className="absolute right-2.5 top-2.5 text-muted" aria-label={show ? 'Hide password' : 'Show password'}>
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          <div className="mb-5 flex items-center justify-between text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" defaultChecked className="rounded border-line text-brand focus:ring-brand" /> Remember me</label>
            <a href="#forgot" className="font-semibold text-brand">Forgot password?</a>
          </div>

          <fieldset className="mb-5">
            <legend className="label">Demo access: preview a role</legend>
            <div className="space-y-2">
              {ROLES.map((r) => (
                <label key={r} className={`flex cursor-pointer items-start gap-3 rounded-lg border px-3 py-2.5 ${role === r ? 'border-brand bg-brand-soft' : 'border-line hover:bg-surface'}`}>
                  <input type="radio" name="role" checked={role === r} onChange={() => setRole(r)} className="mt-1 text-brand focus:ring-brand" />
                  <span>
                    <span className="block text-sm font-bold">{r}</span>
                    <span className="block text-xs text-muted">{ROLE_NOTE[r]}</span>
                  </span>
                </label>
              ))}
            </div>
          </fieldset>

          <button className="btn-dark w-full py-2.5" type="submit">Sign in as {role}</button>
          <div className="mt-4"><Notice tone="violet">Demo access only. Real authentication will be added with the backend.</Notice></div>
        </form>
      </div>
    </div>
  )
}
