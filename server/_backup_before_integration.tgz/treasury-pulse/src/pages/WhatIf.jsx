import { useMemo, useState } from 'react'
import { CartesianGrid, Legend, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useThresholds } from '../context/ThresholdContext'
import { COUNTERPARTY_DATA, FX_TO_USD, compact, entitySeries, money, signedMoney, todayKey, withThresholds } from '../data/mock'
import { Card, chartTooltipStyle, DemoTag, KpiCard, Notice, PageHeader, Select, Tabs } from '../components/ui'
import { Info } from 'lucide-react'

const TABS = ['Payment timing', 'Capex postponement', 'FX rate shock', 'Interest rate change', 'Counterparty rating shift']
const RATING_DELAY = { A: 0, B: 2, C: 5, D: 8 }

function Slider({ label, min, max, step = 1, value, onChange, format = (v) => v, marks }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs"><span className="font-semibold text-muted">{label}</span><span className="rounded bg-brand-soft px-2 py-0.5 font-bold text-brand-dark">{format(value)}</span></div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-brand" aria-label={label} />
      {marks && <div className="mt-1 flex justify-between text-[11px] text-muted">{marks.map((m) => <span key={m}>{m}</span>)}</div>}
    </div>
  )
}

export default function WhatIf() {
  const { thresholds } = useThresholds()
  const entities = useMemo(() => withThresholds(thresholds), [thresholds])
  const [tab, setTab] = useState(TABS[0])
  const [id, setId] = useState('EU01')
  const [delay, setDelay] = useState(3)
  const [postpone, setPostpone] = useState(7)
  const [fx, setFx] = useState(-10)
  const [bps, setBps] = useState(100)
  const [cp, setCp] = useState('Global Inc')
  const [newRating, setNewRating] = useState('D')
  const [applied, setApplied] = useState(true)

  const e = entities.find((x) => x.id === id)
  const forecast = useMemo(() => entitySeries(e).filter((d) => d.i >= 0), [e])
  const dailyOut = e.outflow / 30
  const dailyIn = e.inflow / 30
  const capex = e.balance * 0.18
  const fxMode = tab === 'FX rate shock'
  const ccyOut = fxMode ? 'USD' : e.currency
  const unit = fxMode ? FX_TO_USD[e.currency] : 1
  const oldRating = COUNTERPARTY_DATA.find((c) => c.name === cp).rating

  const rows = forecast.map((d) => {
    const i = d.i
    const base = d.forecast
    let scen = base
    if (applied) {
      if (tab === 'Payment timing') {
        const boost = dailyOut * delay
        scen = base + (i === 0 ? 0 : i <= 30 - delay ? boost : (boost * (30 - i)) / Math.max(delay, 1))
      } else if (tab === 'Capex postponement') {
        scen = base + (i >= 8 && i < 8 + postpone ? capex : 0)
      } else if (tab === 'FX rate shock') {
        scen = base * (1 + fx / 100)
      } else if (tab === 'Interest rate change') {
        scen = base + (e.balance * (bps / 10000) * i) / 365
      } else {
        const extra = Math.max(RATING_DELAY[newRating] - RATING_DELAY[oldRating], 0)
        scen = base - (dailyIn * 0.25 * extra * Math.min(i, 20)) / 10
      }
    }
    return { date: d.date, baseline: Math.round(base * unit), scenario: Math.round(scen * unit) }
  })

  const threshold = e.threshold * unit
  const minBase = Math.min(...rows.map((r) => r.baseline))
  const minScen = Math.min(...rows.map((r) => r.scenario))
  const gapBase = minBase - threshold
  const gapScen = minScen - threshold
  const daysBelow = (k) => rows.filter((r) => r[k] < threshold).length
  const surplus = Math.max(Math.max(...rows.map((r) => r.scenario)) - threshold * 1.1, 0)

  return (
    <div className="space-y-4">
      <PageHeader title="What-if analysis" description="Change one assumption and compare the baseline forecast with the scenario side by side."><DemoTag /></PageHeader>
      <Tabs tabs={TABS} value={tab} onChange={setTab} />

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Scenario parameters">
          <div className="space-y-5">
            <Select label="Entity" value={id} onChange={setId} options={entities.map((x) => ({ value: x.id, label: `${x.id} · ${x.currency}` }))} />
            {tab === 'Payment timing' && <Slider label="Payment delay (days)" min={1} max={5} value={delay} onChange={setDelay} format={(v) => `+${v} day${v > 1 ? 's' : ''}`} marks={['+1', '+2', '+3', '+4', '+5']} />}
            {tab === 'Capex postponement' && <Slider label="Postpone capital spend (days)" min={0} max={30} value={postpone} onChange={setPostpone} format={(v) => `${v} days`} marks={['0', '10', '20', '30']} />}
            {tab === 'FX rate shock' && <Slider label={`${e.currency}/USD rate change`} min={-15} max={15} step={5} value={fx} onChange={setFx} format={(v) => `${v > 0 ? '+' : ''}${v}%`} marks={['-15%', '-10%', '-5%', '0', '+5%', '+10%', '+15%']} />}
            {tab === 'Interest rate change' && <Slider label="Rate change" min={-200} max={200} step={50} value={bps} onChange={setBps} format={(v) => `${v > 0 ? '+' : ''}${v} bps`} marks={['-200', '-100', '0', '+100', '+200']} />}
            {tab === 'Counterparty rating shift' && (
              <>
                <Select label="Counterparty" value={cp} onChange={setCp} options={COUNTERPARTY_DATA.map((c) => c.name)} />
                <Select label={`New rating (current: ${oldRating})`} value={newRating} onChange={setNewRating} options={['A', 'B', 'C', 'D']} />
              </>
            )}
            <button className="btn-primary w-full" onClick={() => setApplied(true)}>Run scenario</button>
            <button className="btn-outline w-full" onClick={() => setApplied(false)}>Reset to baseline</button>
          </div>
        </Card>

        <Card title={`Scenario result · ${e.id} (${ccyOut})`} subtitle={fxMode ? 'USD equivalent at shocked rate' : `Amounts in ${e.currency}`} className="xl:col-span-2">
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="#E3E9F2" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748B' }} interval={5} tickLine={false} />
                <YAxis tickFormatter={(v) => compact(v)} tick={{ fontSize: 11, fill: '#64748B' }} width={56} tickLine={false} axisLine={false} domain={['auto', 'auto']} />
                <Tooltip {...chartTooltipStyle} formatter={(v, n) => [money(v, ccyOut), n]} />
                <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />
                <Line dataKey="baseline" name="Baseline" stroke="#3478F6" strokeWidth={2.25} dot={false} />
                <Line dataKey="scenario" name="Scenario" stroke="#7C6BD6" strokeWidth={2.25} strokeDasharray="6 4" dot={false} />
                <ReferenceLine y={threshold} stroke="#DC2626" strokeDasharray="4 4" label={{ value: 'Threshold', fontSize: 11, fill: '#DC2626', position: 'insideTopRight' }} />
                <ReferenceLine x={todayKey} stroke="#94A3B8" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card title="Impact summary" subtitle="Baseline compared with scenario over the next 30 days">
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard label="Liquidity gap (lowest point)" value={signedMoney(gapScen, ccyOut)} note={`Baseline ${signedMoney(gapBase, ccyOut)}`} noteTone={gapScen >= gapBase ? 'green' : 'red'} />
          <KpiCard label="Days below threshold" value={daysBelow('scenario')} note={`Baseline ${daysBelow('baseline')}`} noteTone={daysBelow('scenario') <= daysBelow('baseline') ? 'green' : 'red'} accent="red" />
          <KpiCard label="Surplus deployment opportunity" value={money(Math.round(surplus), ccyOut)} accent="green" />
          <KpiCard label="Change at day 30" value={signedMoney(rows.at(-1).scenario - rows.at(-1).baseline, ccyOut)} accent="violet" />
        </div>
        <div className="mt-3"><Notice tone="blue" icon={Info}>Scenario maths here is a simple frontend illustration. Final impact figures will come from the forecasting API.</Notice></div>
      </Card>
    </div>
  )
}
