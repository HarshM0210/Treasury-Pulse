import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Area, CartesianGrid, Cell, ComposedChart, Legend, Line, Pie, PieChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { AlertTriangle, ArrowDownRight, ArrowUpRight, Banknote, CalendarClock, FlaskConical, ShieldAlert, Users } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useThresholds } from '../context/ThresholdContext'
import {
  ALERTS, CURRENCIES, REGIONS, compact, currencyBreakdown, money, signedMoney, todayKey, todayLabel, toUsd, totalSeries, withThresholds,
} from '../data/mock'
import { Badge, Card, chartTooltipStyle, DemoTag, KpiCard, PageHeader, Select, StatusBadge } from '../components/ui'

function CashTrend({ entities, thresholdUsd }) {
  const data = useMemo(() => totalSeries(entities), [entities])
  return (
    <Card title="Cash position trend" subtitle="USD equivalent at demo FX rates · 30 days actual, 30 days forecast" className="h-full">
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="#E3E9F2" strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748B' }} interval={7} tickLine={false} />
            <YAxis tickFormatter={(v) => compact(v, 'USD')} tick={{ fontSize: 11, fill: '#64748B' }} width={56} tickLine={false} axisLine={false} domain={['auto', 'auto']} />
            <Tooltip {...chartTooltipStyle} formatter={(v, n) => (Array.isArray(v) ? [`${money(v[0])} – ${money(v[1])}`, n] : [money(v), n])} />
            <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />
            <Area dataKey="band" name="Confidence range" stroke="none" fill="#3478F6" fillOpacity={0.14} connectNulls={false} />
            <Line dataKey="actual" name="Actual" stroke="#3478F6" strokeWidth={2.25} dot={false} connectNulls={false} />
            <Line dataKey="forecast" name="Forecast" stroke="#7C6BD6" strokeWidth={2.25} strokeDasharray="6 4" dot={false} connectNulls={false} />
            <ReferenceLine y={thresholdUsd} stroke="#DC2626" strokeDasharray="4 4" label={{ value: 'Combined threshold', fontSize: 11, fill: '#DC2626', position: 'insideBottomRight' }} />
            <ReferenceLine x={todayKey} stroke="#94A3B8" label={{ value: 'Today', fontSize: 11, fill: '#64748B', position: 'top' }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

function CurrencyDonut({ rows }) {
  const total = rows.reduce((a, r) => a + r.value, 0)
  return (
    <Card title="Currency breakdown" subtitle="Share of cash, USD equivalent" className="h-full">
      <div className="flex flex-col items-center gap-4 sm:flex-row lg:flex-col xl:flex-row">
        <div className="relative h-44 w-44 shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={rows} dataKey="value" nameKey="name" innerRadius={56} outerRadius={80} paddingAngle={2} stroke="none">
                {rows.map((r) => <Cell key={r.name} fill={r.color} />)}
              </Pie>
              <Tooltip {...chartTooltipStyle} formatter={(v, n) => [money(v), n]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-heading text-lg font-extrabold">{compact(total, 'USD')}</span>
            <span className="text-[11px] text-muted">Total</span>
          </div>
        </div>
        <ul className="w-full space-y-2 text-sm">
          {rows.map((r) => (
            <li key={r.name} className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: r.color }} />
              <span className="font-semibold">{r.name}</span>
              <span className="ml-auto tabular-nums text-muted">{r.pct.toFixed(1)}%</span>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  )
}

function LiquidityGapTable({ rows, onRow }) {
  return (
    <Card title="Liquidity gap by entity" subtitle="Gap = projected position − threshold, in the entity's own currency" pad={false}>
      <div className="mt-3 overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr>
              {['Entity', 'Currency', 'Projected position', 'Threshold', 'Liquidity gap', 'Status'].map((h) => <th key={h} className="th">{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id} className="cursor-pointer hover:bg-surface" onClick={() => onRow?.(e)}>
                <td className="td font-semibold">{e.id}</td>
                <td className="td">{e.currency}</td>
                <td className="td tabular-nums">{money(e.projected, e.currency)}</td>
                <td className="td tabular-nums text-muted">{money(e.threshold, e.currency)}</td>
                <td className={`td font-semibold tabular-nums ${e.gap < 0 ? 'text-crit' : 'text-ok'}`}>{signedMoney(e.gap, e.currency)}</td>
                <td className="td"><StatusBadge status={e.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}

function PriorityActions() {
  const navigate = useNavigate()
  const actions = [
    { icon: ShieldAlert, tone: 'text-crit bg-crit-soft', title: 'Liquidity shortfall detected', body: 'EU01 is projected below its EUR threshold before month end.', cta: 'Review alert', to: '/alerts' },
    { icon: CalendarClock, tone: 'text-warn bg-warn-soft', title: 'Upcoming high-value payment', body: 'A large EUR payroll payment is due in 3 days.', cta: 'View transactions', to: '/transactions' },
    { icon: Users, tone: 'text-warn bg-warn-soft', title: 'Counterparty reliability concern', body: 'Global Inc (rating C) is paying later each month.', cta: 'Open counterparty risk', to: '/counterparty' },
    { icon: FlaskConical, tone: 'text-brand bg-brand-soft', title: 'Test a payment-delay scenario', body: 'See how a 3-day delay changes the EU01 gap.', cta: 'Run scenario', to: '/what-if' },
  ]
  return (
    <Card title="Priority actions">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {actions.map(({ icon: Icon, tone, title, body, cta, to }) => (
          <div key={title} className="flex flex-col rounded-lg border border-line p-3.5">
            <span className={`mb-2 flex h-8 w-8 items-center justify-center rounded-lg ${tone}`}><Icon size={16} /></span>
            <p className="text-sm font-bold">{title}</p>
            <p className="mt-1 flex-1 text-xs text-muted">{body}</p>
            <button className="btn-outline mt-3 !py-1.5 text-xs" onClick={() => navigate(to)}>{cta}</button>
          </div>
        ))}
      </div>
    </Card>
  )
}

function AnalystOverview({ rows, thresholdUsd }) {
  const navigate = useNavigate()
  const inflow = rows.reduce((a, e) => a + toUsd(e.inflow, e.currency), 0)
  const outflow = rows.reduce((a, e) => a + toUsd(e.outflow, e.currency), 0)
  const cash = rows.reduce((a, e) => a + toUsd(e.balance, e.currency), 0)
  const atRisk = rows.filter((e) => e.status !== 'surplus')
  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Total cash position (USD eq.)" value={money(cash)} note="+2.4% vs last week" noteTone="green" icon={Banknote} />
        <KpiCard label="Total inflows, next 30 days" value={money(inflow)} note="+12% vs last period" noteTone="green" icon={ArrowUpRight} accent="green" />
        <KpiCard label="Total outflows, next 30 days" value={money(outflow)} note="+8% vs last period" noteTone="red" icon={ArrowDownRight} accent="red" />
        <KpiCard label="Entities at risk" value={atRisk.length} note={`${atRisk.filter((e) => e.status === 'critical').length} critical, ${atRisk.filter((e) => e.status === 'warning').length} warning`} noteTone="red" icon={AlertTriangle} accent="amber" />
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2"><CashTrend entities={rows} thresholdUsd={thresholdUsd} /></div>
        <CurrencyDonut rows={currencyBreakdown()} />
      </div>
      <LiquidityGapTable rows={rows} onRow={() => navigate('/forecasts')} />
      <PriorityActions />
    </>
  )
}

function ManagerOverview({ rows, thresholdUsd, admin }) {
  const navigate = useNavigate()
  const [region, setRegion] = useState('All Regions')
  const [ccy, setCcy] = useState('All Currencies')
  const filtered = rows.filter((e) => (region === 'All Regions' || e.region === region) && (ccy === 'All Currencies' || e.currency === ccy))
  const cash = filtered.reduce((a, e) => a + toUsd(e.balance, e.currency), 0)
  const inflow = filtered.reduce((a, e) => a + toUsd(e.inflow, e.currency), 0)
  const outflow = filtered.reduce((a, e) => a + toUsd(e.outflow, e.currency), 0)
  const byRegion = REGIONS.map((r) => ({
    region: r,
    value: rows.filter((e) => e.region === r).reduce((a, e) => a + toUsd(e.balance, e.currency), 0),
  }))
  const maxRegion = Math.max(...byRegion.map((r) => r.value))
  const events = [
    { date: '12 Oct', entity: 'EU01', desc: 'Payroll payment', amount: 18500, ccy: 'EUR', type: 'Outflow', status: 'critical' },
    { date: '13 Oct', entity: 'US001', desc: 'Tax payment', amount: 14200, ccy: 'USD', type: 'Outflow', status: 'warning' },
    { date: '15 Oct', entity: 'AP01', desc: 'Supplier settlement', amount: 2100000, ccy: 'JPY', type: 'Outflow', status: 'warning' },
    { date: '16 Oct', entity: 'UK01', desc: 'Customer receipt (Global Inc)', amount: 9800, ccy: 'GBP', type: 'Inflow', status: 'warning' },
  ]
  return (
    <>
      <div className="flex flex-wrap gap-3">
        <Select className="w-44" value={region} onChange={setRegion} options={['All Regions', ...REGIONS]} />
        <Select className="w-44" value={ccy} onChange={setCcy} options={['All Currencies', ...CURRENCIES]} />
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Global cash position (USD eq.)" value={money(cash)} note="+1.9% this week" noteTone="green" icon={Banknote} />
        <KpiCard label="Total inflows (USD eq.)" value={money(inflow)} icon={ArrowUpRight} accent="green" />
        <KpiCard label="Total outflows (USD eq.)" value={money(outflow)} icon={ArrowDownRight} accent="red" />
        <KpiCard label="Net position (USD eq.)" value={signedMoney(inflow - outflow, 'USD')} note={inflow - outflow < 0 ? 'Net outflow expected' : 'Net inflow expected'} noteTone={inflow - outflow < 0 ? 'red' : 'green'} icon={Banknote} accent="violet" />
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        <div className="xl:col-span-2 space-y-4">
          <Card title="Cash position by region" subtitle="USD equivalent · select an entity row below to drill down">
            <div className="space-y-4">
              {byRegion.map((r) => (
                <button key={r.region} onClick={() => setRegion(r.region)} className="block w-full text-left">
                  <div className="mb-1 flex justify-between text-sm"><span className="font-bold">{r.region}</span><span className="tabular-nums">{money(r.value)}</span></div>
                  <div className="h-2.5 rounded-full bg-surface"><div className="h-2.5 rounded-full bg-brand" style={{ width: `${(r.value / maxRegion) * 100}%` }} /></div>
                </button>
              ))}
            </div>
          </Card>
          <LiquidityGapTable rows={filtered} onRow={() => navigate('/forecasts')} />
        </div>
        <CurrencyDonut rows={currencyBreakdown()} />
      </div>
      <Card title="Upcoming critical events" subtitle="Next 7 days" pad={false}>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full">
            <thead><tr>{['Date', 'Entity', 'Description', 'Amount', 'Type', 'Status'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
            <tbody>
              {events.map((e) => (
                <tr key={e.desc} className="hover:bg-surface">
                  <td className="td">{e.date}</td><td className="td font-semibold">{e.entity}</td><td className="td">{e.desc}</td>
                  <td className="td tabular-nums">{money(e.amount, e.ccy)}</td><td className="td"><StatusBadge status={e.type} /></td><td className="td"><StatusBadge status={e.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      {admin && (
        <Card title="System summary" subtitle="Admin only">
          <div className="grid gap-3 sm:grid-cols-3">
            {[['Active users', '4 of 5'], ['Open alerts', String(ALERTS.filter((a) => a.status === 'Open').length)], ['Scheduled reports', '2 enabled']].map(([k, v]) => (
              <div key={k} className="rounded-lg border border-line p-3.5"><p className="text-xs font-semibold text-muted">{k}</p><p className="mt-1 font-heading text-xl font-extrabold">{v}</p></div>
            ))}
          </div>
        </Card>
      )}
    </>
  )
}

export default function Overview() {
  const { role } = useAuth()
  const { thresholds } = useThresholds()
  const rows = useMemo(() => withThresholds(thresholds), [thresholds])
  const thresholdUsd = rows.reduce((a, e) => a + toUsd(e.threshold, e.currency), 0)

  const titles = {
    Analyst: ['Overview', 'Entity-level cash, 30-day outlook and liquidity gaps for your assigned entities.'],
    'Treasury Manager': ['Regional overview', 'Cross-entity liquidity by region, with drill-down into individual entities.'],
    Admin: ['Global overview', 'System-wide liquidity, with access to users, thresholds and report scheduling.'],
  }
  return (
    <div className="space-y-4">
      <PageHeader title={titles[role][0]} description={titles[role][1]}>
        <DemoTag />
        <Badge tone="grey">{todayLabel}</Badge>
      </PageHeader>
      {role === 'Analyst' ? (
        <AnalystOverview rows={rows} thresholdUsd={thresholdUsd} />
      ) : (
        <ManagerOverview rows={rows} thresholdUsd={thresholdUsd} admin={role === 'Admin'} />
      )}
    </div>
  )
}
