import { useState } from 'react'
import { Check, Pencil, Plus, UserCheck, UserX } from 'lucide-react'
import { useThresholds } from '../context/ThresholdContext'
import { CURRENCIES, DEFAULT_THRESHOLDS, INITIAL_USERS, PERMISSIONS, money } from '../data/mock'
import { Badge, Card, DemoTag, Modal, Notice, PageHeader, Select, StatusBadge, Tabs } from '../components/ui'

const ROLE_OPTIONS = ['Analyst', 'Treasury Manager', 'Admin']
const blank = { name: '', email: '', role: 'Analyst', status: 'Active' }
const roleTone = { Analyst: 'green', 'Treasury Manager': 'blue', Admin: 'violet' }

function UserManagement() {
  const [users, setUsers] = useState(INITIAL_USERS)
  const [form, setForm] = useState(null)
  const valid = form && form.name.trim() && /^\S+@\S+\.\S+$/.test(form.email)

  const save = () => {
    if (!valid) return
    setUsers(form.id ? users.map((u) => (u.id === form.id ? form : u)) : [...users, { ...form, id: Date.now() }])
    setForm(null)
  }
  const toggle = (id) => setUsers(users.map((u) => (u.id === id ? { ...u, status: u.status === 'Active' ? 'Suspended' : 'Active' } : u)))

  return (
    <Card title="Users" subtitle="Changes are kept in this browser session only" action={<button className="btn-primary" onClick={() => setForm(blank)}><Plus size={15} /> Add user</button>} pad={false}>
      <div className="mt-3 overflow-x-auto">
        <table className="w-full">
          <thead><tr>{['Name', 'Email', 'Role', 'Data access', 'Status', 'Actions'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-surface">
                <td className="td font-semibold">{u.name}</td><td className="td">{u.email}</td>
                <td className="td"><Badge tone={roleTone[u.role]}>{u.role}</Badge></td><td className="td">{u.scope || 'Assigned by backend'}</td>
                <td className="td"><StatusBadge status={u.status} /></td>
                <td className="td">
                  <div className="flex gap-1.5">
                    <button className="btn-outline !px-2.5 !py-1 text-xs" onClick={() => setForm(u)}><Pencil size={12} /> Edit</button>
                    <button className="btn-outline !px-2.5 !py-1 text-xs" onClick={() => toggle(u.id)}>{u.status === 'Active' ? <><UserX size={12} /> Suspend</> : <><UserCheck size={12} /> Activate</>}</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal open={!!form} title={form?.id ? 'Edit user' : 'Add user'} onClose={() => setForm(null)}
        footer={<><button className="btn-outline" onClick={() => setForm(null)}>Cancel</button><button className="btn-primary" disabled={!valid} onClick={save}>{form?.id ? 'Save changes' : 'Add user'}</button></>}>
        {form && (
          <>
            <div><label className="label" htmlFor="un">Full name</label><input id="un" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><label className="label" htmlFor="ue">Email</label><input id="ue" type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <Select label="Role" value={form.role} onChange={(v) => setForm({ ...form, role: v })} options={ROLE_OPTIONS} />
          </>
        )}
      </Modal>
    </Card>
  )
}

function Permissions() {
  return (
    <Card title="Role permissions" subtitle="Proposed UI policy. Edit PERMISSIONS in src/data/mock.js if the team agrees on changes." pad={false}>
      <div className="mt-3 overflow-x-auto">
        <table className="w-full">
          <thead><tr>{['Capability', 'Analyst', 'Treasury Manager', 'Admin'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
          <tbody>
            {PERMISSIONS.map((p) => (
              <tr key={p.capability}>
                <td className="td font-semibold">{p.capability}</td>
                {[p.analyst, p.manager, p.admin].map((v, i) => (
                  <td key={i} className="td"><Badge tone={v === 'No' ? 'grey' : v === 'Limited' || v === 'Personal' ? 'amber' : 'green'}>{v}</Badge></td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}

function Thresholds() {
  const { thresholds, setThresholds } = useThresholds()
  const [draft, setDraft] = useState(thresholds)
  const [saved, setSaved] = useState(null)

  const save = (c) => {
    const v = Number(draft[c])
    if (!Number.isFinite(v) || v <= 0) return
    setThresholds({ ...thresholds, [c]: v })
    setSaved(c)
    setTimeout(() => setSaved(null), 1800)
  }

  return (
    <Card title="Minimum cash thresholds" subtitle="Each currency has its own threshold. They are never converted or applied across currencies.">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {CURRENCIES.map((c) => (
          <div key={c} className="rounded-lg border border-line p-4">
            <div className="mb-2 flex items-center justify-between"><span className="font-heading text-base font-extrabold">{c}</span><span className="text-xs text-muted">Default {money(DEFAULT_THRESHOLDS[c], c)}</span></div>
            <label className="label" htmlFor={`t-${c}`}>Minimum balance ({c})</label>
            <input id={`t-${c}`} type="number" min="1" className="input" value={draft[c]} onChange={(e) => setDraft({ ...draft, [c]: e.target.value })} />
            <button className="btn-primary mt-3 w-full" onClick={() => save(c)}>{saved === c ? <><Check size={15} /> Saved</> : 'Save'}</button>
          </div>
        ))}
      </div>
      <div className="mt-4"><Notice tone="blue">Saved thresholds update the dashboards, forecasts and alert matrix immediately in this demo.</Notice></div>
    </Card>
  )
}

export default function Settings() {
  const [tab, setTab] = useState('User management')
  return (
    <div className="space-y-4">
      <PageHeader title="Settings" description="Administer users, role permissions and per-currency thresholds."><DemoTag /></PageHeader>
      <Tabs tabs={['User management', 'Role permissions', 'Threshold configuration']} value={tab} onChange={setTab} />
      {tab === 'User management' && <UserManagement />}
      {tab === 'Role permissions' && <Permissions />}
      {tab === 'Threshold configuration' && <Thresholds />}
    </div>
  )
}
