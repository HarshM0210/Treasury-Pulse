import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search } from 'lucide-react'
import { COUNTERPARTY_DATA } from '../data/mock'
import { Card, DemoTag, KpiCard, PageHeader, RatingBadge, Select, Sparkline } from '../components/ui'

const TREND_COLOR = { A: '#16A34A', B: '#3478F6', C: '#D97706', D: '#DC2626' }
const RATING_LABEL = { A: 'Low risk', B: 'Medium risk', C: 'High risk', D: 'High risk' }

export default function CounterpartyRisk() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [rating, setRating] = useState('All Ratings')
  const [selected, setSelected] = useState(COUNTERPARTY_DATA[2])

  const rows = COUNTERPARTY_DATA.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()) && (rating === 'All Ratings' || c.rating === rating))
  const n = (list) => COUNTERPARTY_DATA.filter((c) => list.includes(c.rating)).length

  return (
    <div className="space-y-4">
      <PageHeader title="Counterparty risk" description="Payment reliability by counterparty. Ratings feed forecast confidence: A is high confidence, D is low."><DemoTag /></PageHeader>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Total counterparties" value={COUNTERPARTY_DATA.length} />
        <KpiCard label="High risk (C, D)" value={n(['C', 'D'])} accent="red" />
        <KpiCard label="Medium risk (B)" value={n(['B'])} accent="amber" />
        <KpiCard label="Low risk (A)" value={n(['A'])} accent="green" />
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Counterparty risk ratings" className="xl:col-span-2" pad={false}>
          <div className="flex flex-wrap gap-3 px-5 pb-3 pt-4">
            <label className="relative w-60"><span className="sr-only">Search counterparty</span><Search size={15} className="absolute left-3 top-3 text-muted" /><input className="input pl-9" placeholder="Search counterparty" value={q} onChange={(e) => setQ(e.target.value)} /></label>
            <Select className="w-40" value={rating} onChange={setRating} options={['All Ratings', 'A', 'B', 'C', 'D']} />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr>{['Counterparty', 'Rating', 'Transactions', 'Failure rate', 'Avg. delay (days)', 'Trend'].map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
              <tbody>
                {rows.map((c) => (
                  <tr key={c.name} onClick={() => setSelected(c)} className={`cursor-pointer hover:bg-surface ${selected.name === c.name ? 'bg-brand-soft/50' : ''}`}>
                    <td className="td font-semibold">{c.name}</td><td className="td"><RatingBadge rating={c.rating} /></td>
                    <td className="td tabular-nums">{c.transactions.toLocaleString()}</td><td className="td tabular-nums">{c.failureRate}%</td><td className="td tabular-nums">{c.avgDelay}</td>
                    <td className="td"><Sparkline data={c.trend} color={TREND_COLOR[c.rating]} /></td>
                  </tr>
                ))}
                {rows.length === 0 && <tr><td colSpan={6} className="td py-10 text-center text-muted">No counterparties match. Clear the search or rating filter.</td></tr>}
              </tbody>
            </table>
          </div>
        </Card>

        <Card title="Risk details">
          <div className="mb-4 flex items-center gap-3"><RatingBadge rating={selected.rating} /><div><p className="font-heading text-lg font-extrabold leading-tight">{selected.name}</p><p className="text-xs text-muted">{RATING_LABEL[selected.rating]}</p></div></div>
          <dl className="space-y-2 text-sm">
            {[['Failure rate', `${selected.failureRate}%`], ['Avg. payment delay', `${selected.avgDelay} days`], ['Total transactions', selected.transactions.toLocaleString()]].map(([k, v]) => (
              <div key={k} className="flex justify-between border-b border-line pb-2"><dt className="text-muted">{k}</dt><dd className="font-semibold tabular-nums">{v}</dd></div>
            ))}
          </dl>
          <p className="label mt-4">Last 6 months: average delay trend</p>
          <div className="h-16 w-full"><Sparkline data={selected.trend} color={TREND_COLOR[selected.rating]} /></div>
          <div className="mt-4 flex flex-col gap-2">
            <button className="btn-primary" onClick={() => navigate('/transactions')}>View transaction history</button>
            <button className="btn-outline" onClick={() => navigate('/what-if')}>Simulate a rating downgrade</button>
          </div>
        </Card>
      </div>
    </div>
  )
}
