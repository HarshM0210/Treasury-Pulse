import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { AuthProvider } from './context/AuthContext'
import { ThresholdProvider } from './context/ThresholdContext'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <ThresholdProvider>
          <App />
        </ThresholdProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
)
