import { useCallback, useState } from 'react'
import { askAssistant } from '../services/api'

const WELCOME = {
  role: 'assistant',
  content: "Hi, I'm Pulse Assistant. Ask about cash positions, forecasts, alerts or counterparties.",
}

/**
 * Shared chat state for the floating widget and the AI Assistant page.
 * The only backend touchpoint is askAssistant() in services/api.js.
 */
export function useChat(context = {}) {
  const [messages, setMessages] = useState([WELCOME])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const send = useCallback(
    async (text) => {
      const message = text.trim()
      if (!message || loading) return
      const history = messages
      setMessages((m) => [...m, { role: 'user', content: message }])
      setLoading(true)
      setError(null)
      try {
        const { reply } = await askAssistant({ message, history, context })
        setMessages((m) => [...m, { role: 'assistant', content: reply }])
      } catch {
        setError('The assistant could not be reached. Check your connection and try again.')
      } finally {
        setLoading(false)
      }
    },
    [messages, loading, context]
  )

  const reset = useCallback(() => {
    setMessages([WELCOME])
    setError(null)
  }, [])

  return { messages, loading, error, send, reset }
}
