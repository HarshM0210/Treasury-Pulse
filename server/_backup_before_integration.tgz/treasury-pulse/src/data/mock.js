// ─────────────────────────────────────────────────────────────
// DEMO DATA ONLY. Replace with API responses (see services/api.js).
// Amounts are in each entity's own currency. Different currencies
// are never added together except through the explicit FX table below.
// ─────────────────────────────────────────────────────────────

export const ROLES = ['Analyst', 'Treasury Manager', 'Admin']
export const REGIONS = ['NAM', 'EMEA', 'APAC']
export const CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'CAD']

// Demo FX rates → USD (used only for explicit "USD equivalent" totals)
export const FX_TO_USD = { USD: 1, EUR: 1.08, GBP: 1.27, JPY: 0.0067, CAD: 0.73 }

// Minimum cash thresholds, per currency (editable in Settings → Threshold Configuration)
export const DEFAULT_THRESHOLDS = { EUR: 50000, USD: 60000, JPY: 5000000, GBP: 40000, CAD: 25000 }

export const ENTITIES = [
  { id: 'US001', name: 'Northwind Inc.', region: 'NAM', currency: 'USD', balance: 92400, projected: 84200, inflow: 61000, outflow: 69200 },
  { id: 'CA01', name: 'Northwind Canada', region: 'NAM', currency: 'CAD', balance: 35000, projected: 33100, inflow: 18400, outflow: 20300 },
  { id: 'EU01', name: 'Northwind Europe GmbH', region: 'EMEA', currency: 'EUR', balance: 58300, projected: 44100, inflow: 40200, outflow: 54400 },
  { id: 'UK01', name: 'Northwind UK Ltd', region: 'EMEA', currency: 'GBP', balance: 47900, projected: 43400, inflow: 22100, outflow: 26600 },
  { id: 'AP01', name: 'Northwind Japan KK', region: 'APAC', currency: 'JPY', balance: 8600000, projected: 7900000, inflow: 4100000, outflow: 4800000 },
]

export const toUsd = (amount, ccy) => amount * (FX_TO_USD[ccy] ?? 1)

// Dashboard bands: green >10% above threshold, amber 5–10%, red <5% above or negative gap
export function statusOf(projected, threshold) {
  const ratio = (projected - threshold) / threshold
  if (ratio > 0.1) return 'surplus'
  if (ratio >= 0.05) return 'warning'
  return 'critical'
}

// Alert engine levels: Warning 5–10%, Critical 0–5%, Emergency below threshold
export function alertLevel(projected, threshold) {
  const ratio = (projected - threshold) / threshold
  if (ratio < 0) return 'emergency'
  if (ratio < 0.05) return 'critical'
  if (ratio <= 0.1) return 'warning'
  return null
}

export function withThresholds(thresholds = DEFAULT_THRESHOLDS) {
  return ENTITIES.map((e) => {
    const threshold = thresholds[e.currency]
    return { ...e, threshold, gap: e.projected - threshold, status: statusOf(e.projected, threshold) }
  })
}

// ── Formatting ───────────────────────────────────────────────
export const money = (n, ccy = 'USD', opts = {}) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: ccy, maximumFractionDigits: 0, ...opts }).format(n)

export const signedMoney = (n, ccy) => (n > 0 ? '+' : n < 0 ? '−' : '') + money(Math.abs(n), ccy)

export const compact = (n, ccy) =>
  new Intl.NumberFormat('en-US', {
    style: ccy ? 'currency' : 'decimal',
    currency: ccy,
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(n)

// ── Deterministic pseudo-random so charts look the same on every reload ──
function rng(seed) {
  let s = seed
  return () => (s = (s * 9301 + 49297) % 233280) / 233280
}

const fmtDay = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
const addDays = (d, n) => {
  const x = new Date(d)
  x.setDate(x.getDate() + n)
  return x
}
export const TODAY = new Date()
export const todayLabel = TODAY.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
export const todayKey = fmtDay(TODAY)

/**
 * 30 days of history + 30 days of forecast with a confidence band.
 * start = balance 30 days ago, now = balance today, end = projected balance in 30 days.
 */
export function buildSeries({ start, now, end, seed = 7, volatility = 0.025 }) {
  const rand = rng(seed)
  const out = []
  for (let i = -30; i <= 30; i++) {
    const date = fmtDay(addDays(TODAY, i))
    const weekly = Math.sin((i / 7) * Math.PI * 2) * now * 0.012
    const noise = (rand() - 0.5) * now * volatility
    if (i <= 0) {
      const base = start + ((now - start) * (i + 30)) / 30
      const v = i === 0 ? now : Math.round(base + weekly + noise)
      out.push({ date, i, actual: v, forecast: i === 0 ? v : null, band: i === 0 ? [v, v] : null })
    } else {
      const base = now + ((end - now) * i) / 30
      const v = Math.round(base + weekly)
      const spread = now * 0.015 + (i / 30) * now * 0.09
      out.push({ date, i, actual: null, forecast: v, band: [Math.round(v - spread), Math.round(v + spread)] })
    }
  }
  return out
}

export function entitySeries(entity) {
  return buildSeries({
    start: entity.balance * 1.06,
    now: entity.balance,
    end: entity.projected,
    seed: entity.id.charCodeAt(0) + entity.id.charCodeAt(1),
  })
}

// Total (USD equivalent) series for the Overview chart
export function totalSeries(entities) {
  const sum = (key) => entities.reduce((a, e) => a + toUsd(e[key], e.currency), 0)
  return buildSeries({ start: sum('balance') * 1.05, now: sum('balance'), end: sum('projected'), seed: 11 })
}

export const REGION_DATA = REGIONS.map((r) => {
  const es = ENTITIES.filter((e) => e.region === r)
  return {
    region: r,
    usdEquivalent: es.reduce((a, e) => a + toUsd(e.balance, e.currency), 0),
    entities: es.length,
  }
})

export function currencyBreakdown() {
  const total = ENTITIES.reduce((a, e) => a + toUsd(e.balance, e.currency), 0)
  const palette = { USD: '#3478F6', EUR: '#7C6BD6', GBP: '#16A34A', JPY: '#F59E0B', CAD: '#5B7399' }
  return ENTITIES.map((e) => ({
    name: e.currency,
    value: Math.round(toUsd(e.balance, e.currency)),
    pct: (toUsd(e.balance, e.currency) / total) * 100,
    color: palette[e.currency],
  }))
}

// ── Transactions ─────────────────────────────────────────────
const COUNTERPARTIES = ['ABC Corp', 'XYZ Ltd', 'Global Inc', 'Finance Co', 'Supply Ltd', 'Orion Logistics', 'Helix Energy', 'Meridian Bank']
const STATUSES = ['Settled', 'Settled', 'Pending', 'Settled', 'Overdue', 'Failed']

export const TRANSACTIONS = (() => {
  const r = rng(42)
  return Array.from({ length: 64 }, (_, k) => {
    const entity = ENTITIES[Math.floor(r() * ENTITIES.length)]
    const direction = r() > 0.48 ? 'Inflow' : 'Outflow'
    const scale = entity.currency === 'JPY' ? 150 : 1
    const amount = Math.round((1500 + r() * 14000) * scale)
    const actual = addDays(TODAY, -Math.floor(r() * 45))
    const due = addDays(actual, Math.floor(r() * 8) - 2)
    return {
      id: `TXN_${String(k + 1).padStart(3, '0')}`,
      actualDate: actual.toISOString().slice(0, 10),
      dueDate: due.toISOString().slice(0, 10),
      entity: entity.id,
      counterparty: COUNTERPARTIES[Math.floor(r() * COUNTERPARTIES.length)],
      amount,
      currency: entity.currency,
      direction,
      status: STATUSES[Math.floor(r() * STATUSES.length)],
    }
  })
})()

// ── Alerts ───────────────────────────────────────────────────
export const ALERTS = [
  { id: 'AL-1042', time: '10 Oct 10:00', entity: 'EU01', currency: 'EUR', projected: 44100, threshold: 50000, severity: 'emergency', status: 'Open', title: 'Liquidity shortfall detected', expected: '28 Oct' },
  { id: 'AL-1041', time: '10 Oct 09:00', entity: 'UK01', currency: 'GBP', projected: 40900, threshold: 40000, severity: 'critical', status: 'Open', title: 'Projected position within 5% of threshold', expected: '03 Nov' },
  { id: 'AL-1040', time: '10 Oct 08:00', entity: 'AP01', currency: 'JPY', projected: 5400000, threshold: 5000000, severity: 'warning', status: 'Open', title: 'Projected position within 10% of threshold', expected: '06 Nov' },
  { id: 'AL-1039', time: '10 Oct 07:00', entity: 'CA01', currency: 'CAD', projected: 25900, threshold: 25000, severity: 'warning', status: 'Open', title: 'Projected position within 10% of threshold', expected: '09 Nov' },
  { id: 'AL-1038', time: '09 Oct 17:00', entity: 'US001', currency: 'USD', projected: 63000, threshold: 60000, severity: 'warning', status: 'Resolved', title: 'Large payment moved; position restored', expected: '—' },
  { id: 'AL-1037', time: '09 Oct 09:00', entity: 'EU01', currency: 'EUR', projected: 49100, threshold: 50000, severity: 'emergency', status: 'Resolved', title: 'Intercompany top-up executed', expected: '—' },
]

// ── Counterparties ───────────────────────────────────────────
export const COUNTERPARTY_DATA = [
  { name: 'ABC Corp', rating: 'A', transactions: 2341, failureRate: 0.5, avgDelay: 1.2, trend: [3, 3, 2, 3, 2, 2] },
  { name: 'XYZ Ltd', rating: 'B', transactions: 1872, failureRate: 1.8, avgDelay: 2.4, trend: [2, 3, 3, 4, 3, 4] },
  { name: 'Global Inc', rating: 'C', transactions: 956, failureRate: 4.5, avgDelay: 5.1, trend: [4, 5, 7, 6, 8, 9] },
  { name: 'Finance Co', rating: 'D', transactions: 420, failureRate: 8.2, avgDelay: 7.3, trend: [6, 7, 8, 9, 9, 11] },
  { name: 'Supply Ltd', rating: 'B', transactions: 1201, failureRate: 2.1, avgDelay: 3.0, trend: [3, 3, 4, 3, 3, 4] },
  { name: 'Orion Logistics', rating: 'A', transactions: 1630, failureRate: 0.7, avgDelay: 1.0, trend: [2, 2, 2, 3, 2, 2] },
  { name: 'Helix Energy', rating: 'B', transactions: 780, failureRate: 1.6, avgDelay: 2.2, trend: [3, 2, 3, 3, 2, 3] },
  { name: 'Meridian Bank', rating: 'A', transactions: 3105, failureRate: 0.3, avgDelay: 0.8, trend: [1, 1, 2, 1, 1, 1] },
]

// ── Users & permissions ──────────────────────────────────────
export const INITIAL_USERS = [
  { id: 1, name: 'John Doe', email: 'john@company.com', role: 'Analyst', scope: 'EU01, UK01', status: 'Active' },
  { id: 2, name: 'Sarah Kim', email: 'sarah@company.com', role: 'Treasury Manager', scope: 'EMEA', status: 'Active' },
  { id: 3, name: 'Ravi Patel', email: 'ravi@company.com', role: 'Admin', scope: 'All data', status: 'Active' },
  { id: 4, name: 'Mei Tanaka', email: 'mei@company.com', role: 'Analyst', scope: 'AP01', status: 'Suspended' },
  { id: 5, name: 'Lucas Meyer', email: 'lucas@company.com', role: 'Treasury Manager', scope: 'NAM', status: 'Active' },
]

export const PERMISSIONS = [
  { capability: 'Assigned entity data', analyst: 'Yes', manager: 'Yes', admin: 'All data' },
  { capability: 'Regional aggregates', analyst: 'Limited', manager: 'Yes', admin: 'Yes' },
  { capability: 'Forecasts', analyst: 'Yes', manager: 'Yes', admin: 'Yes' },
  { capability: 'What-if scenarios', analyst: 'Yes', manager: 'Yes', admin: 'Yes' },
  { capability: 'Alert monitoring', analyst: 'Permitted scope', manager: 'Regional scope', admin: 'Full management' },
  { capability: 'Reports', analyst: 'Personal', manager: 'Regional', admin: 'Full scheduler management' },
  { capability: 'User management', analyst: 'No', manager: 'No', admin: 'Yes' },
  { capability: 'Threshold configuration', analyst: 'No', manager: 'Policy access as approved', admin: 'Yes' },
  { capability: 'System configuration', analyst: 'No', manager: 'No', admin: 'Yes' },
]
