// ─────────────────────────────────────────────────────────────
// API SERVICE LAYER
// Every function here currently returns mock data. When the Django
// backend is ready, replace the body of each function with a real
// request. Pages and components never call fetch() directly, so the
// UI does not need to change.
// ─────────────────────────────────────────────────────────────
import * as mock from '../data/mock'

// eslint-disable-next-line no-unused-vars
const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'
const delay = (ms = 250) => new Promise((r) => setTimeout(r, ms))

// Shape of the real implementation, for your teammates:
// async function request(path, options = {}) {
//   const res = await fetch(`${BASE_URL}${path}`, {
//     credentials: 'include',
//     headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
//     ...options,
//   })
//   if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`)
//   return res.json()
// }

export async function getEntities() { await delay(); return mock.withThresholds() }
export async function getTransactions() { await delay(); return mock.TRANSACTIONS }
export async function getAlerts() { await delay(); return mock.ALERTS }
export async function getCounterparties() { await delay(); return mock.COUNTERPARTY_DATA }
export async function getUsers() { await delay(); return mock.INITIAL_USERS }

// TODO(backend): POST multipart/form-data to /api/transactions/upload
export async function uploadTransactionsCsv(file) {
  // const form = new FormData(); form.append('file', file)
  // return request('/transactions/upload', { method: 'POST', body: form, headers: {} })
  await delay(300)
  return { status: 'not_implemented', filename: file.name, size: file.size }
}

// ─────────────────────────────────────────────────────────────
// AI ASSISTANT HOOK-UP POINT  <-- your teammate integrates here
//
// The floating chat widget and the AI Assistant page both call
// askAssistant(). Replace the body with a real request, e.g.:
//
//   return request('/assistant/chat', {
//     method: 'POST',
//     body: JSON.stringify({ message, history, context }),
//   })
//
// Expected return shape: { reply: string }
// history = [{ role: 'user' | 'assistant', content: string }, ...]
// context = { role, page } so the backend can scope data by user role.
// ─────────────────────────────────────────────────────────────
export async function askAssistant({ message, history = [], context = {} }) {
  await delay(900)
  const q = message.toLowerCase()
  let reply =
    'This is a demo reply. Once the assistant backend is connected, I will answer using live cash positions, forecasts and alerts.'
  if (q.includes('shortfall') || q.includes('risk'))
    reply = 'Demo data: EU01 (EUR) is projected to fall below its EUR 50,000 threshold. A payment-delay scenario or an intercompany top-up could close the gap.'
  else if (q.includes('forecast'))
    reply = 'Demo data: the 30-day forecast shows net outflows across EMEA. Open Forecasts to see the confidence band per entity.'
  else if (q.includes('counterparty'))
    reply = 'Demo data: Global Inc (rating C) and Finance Co (rating D) show rising payment delays. Open Counterparty Risk for details.'
  else if (q.includes('report'))
    reply = 'You can schedule SOD and EOD briefings on the Reports page and export them as CSV or PDF.'
  return { reply, historyLength: history.length, context }
}
