import { createContext, useContext, useState } from 'react'
import { DEFAULT_THRESHOLDS } from '../data/mock'

const ThresholdContext = createContext(null)

export function ThresholdProvider({ children }) {
  const [thresholds, setThresholds] = useState(DEFAULT_THRESHOLDS)
  return <ThresholdContext.Provider value={{ thresholds, setThresholds }}>{children}</ThresholdContext.Provider>
}

export const useThresholds = () => useContext(ThresholdContext)
