import { createContext, useContext, useMemo, useState } from 'react'

const AuthContext = createContext(null)

// DEMO ONLY: the role selector previews role-based UI. It is not real authentication.
export function AuthProvider({ children }) {
  const [signedIn, setSignedIn] = useState(() => localStorage.getItem('tp_signed_in') === '1')
  const [role, setRoleState] = useState(() => localStorage.getItem('tp_role') || 'Analyst')

  const value = useMemo(
    () => ({
      signedIn,
      role,
      setRole: (r) => {
        localStorage.setItem('tp_role', r)
        setRoleState(r)
      },
      signIn: (r) => {
        localStorage.setItem('tp_signed_in', '1')
        localStorage.setItem('tp_role', r)
        setRoleState(r)
        setSignedIn(true)
      },
      signOut: () => {
        localStorage.removeItem('tp_signed_in')
        setSignedIn(false)
      },
    }),
    [signedIn, role]
  )
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
