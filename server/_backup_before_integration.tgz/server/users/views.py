
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404

from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import UserProfile
from .serializers import AdminUserSerializer

User = get_user_model()


class AdminUserViewSet(viewsets.GenericViewSet):
    queryset = User.objects.all()
    serializer_class = AdminUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        self.check_admin()
        return User.objects.select_related("profile").order_by("id")

    def check_admin(self):
        try:
            if self.request.user.profile.role != UserProfile.Role.ADMIN:
                raise PermissionDenied(
                    "Only admins can manage user roles."
                )
        except UserProfile.DoesNotExist:
            raise PermissionDenied(
                "A Treasury Pulse role is required."
            )

    def list(self, request):
        self.check_admin()

        users = User.objects.select_related("profile").order_by("id")
        return Response(self.get_serializer(users, many=True).data)

    @action(detail=True, methods=["patch"], url_path="role")
    def update_role(self, request, pk=None):
        self.check_admin()

        target_user = get_object_or_404(
            User.objects.select_related("profile"),
            pk=pk,
        )

        if target_user.pk == request.user.pk:
            return Response(
                {"detail": "You cannot change your own role here."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        new_role = request.data.get("role")
        if new_role not in UserProfile.Role.values:
            return Response(
                {
                    "role": [
                        "Choose ANALYST, TREASURY_MANAGER, or ADMIN."
                    ]
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        target_user.profile.role = new_role
        target_user.profile.save(update_fields=["role"])

        return Response(self.get_serializer(target_user).data)
