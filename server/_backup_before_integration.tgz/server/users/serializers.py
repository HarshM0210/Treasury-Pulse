
from django.contrib.auth import get_user_model
from rest_framework import serializers

from .models import UserProfile

User = get_user_model()


class AdminUserSerializer(serializers.ModelSerializer):
    role = serializers.ChoiceField(
        choices=UserProfile.Role.choices,
        source="profile.role",
    )

    class Meta:
        model = User
        fields = ["id", "username", "email", "role"]
        read_only_fields = ["id", "username", "email"]
