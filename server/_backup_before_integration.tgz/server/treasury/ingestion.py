
import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation

from collections import defaultdict
from django.db import transaction
from django.db.models import Sum,Q
from .models import Entity, BankAccount, Transaction, CashPosition



REQUIRED_COLUMNS = {
    "transaction_id",
    "due_date(expected)",
    "transaction_date(Actual)",
    "entity",
    "region",
    "country",
    "account_number",
    "currency",
    "original_amount",
    "direction",
    "settlement_status",
    "origin_currency",
    "destination_currency",
    "fx_rate",
}


def validate_csv_headers(fieldnames):
    """Ensure the uploaded CSV contains all required columns."""
    if not fieldnames:
        raise ValueError("The CSV file is empty or has no header row.")

    missing = REQUIRED_COLUMNS - set(fieldnames)

    if missing:
        raise ValueError(
            "Missing required CSV columns: " + ", ".join(sorted(missing))
        )


def parse_csv_date(value, field_name, required=False):
    """Parse dates in the dataset's M/D/YYYY format."""
    value = (value or "").strip()

    if not value:
        if required:
            raise ValueError(f"{field_name} is required.")
        return None

    try:
        return datetime.strptime(value, "%m/%d/%Y").date()
    except ValueError as exc:
        raise ValueError(
            f"Invalid date in {field_name}: {value!r}"
        ) from exc


def parse_csv_decimal(value, field_name, required=True):
    """Parse a decimal value without using floating-point arithmetic."""
    value = (value or "").strip()

    if not value:
        if required:
            raise ValueError(f"{field_name} is required.")
        return None

    try:
        result = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError(
            f"Invalid decimal in {field_name}: {value!r}"
        ) from exc

    if not result.is_finite():
        raise ValueError(f"{field_name} must be a finite number.")

    return result


def normalize_transaction(row):
    """Validate and normalize one CSV transaction row."""
    transaction_id = (row.get("transaction_id") or "").strip()
    entity_name = (row.get("entity") or "").strip()
    region = (row.get("region") or "").strip().upper()
    country = (row.get("country") or "").strip()
    direction = (row.get("direction") or "").strip().lower()
    settlement_status = (
        (row.get("settlement_status") or "").strip().lower()
    )

    if not transaction_id:
        raise ValueError("transaction_id is required.")

    if not entity_name or not region or not country:
        raise ValueError(
            f"{transaction_id}: entity, region, and country are required."
        )

    if direction not in {"inflow", "outflow"}:
        raise ValueError(
            f"{transaction_id}: invalid direction {direction!r}."
        )

    if settlement_status not in {"settled", "failed"}:
        raise ValueError(
            f"{transaction_id}: invalid settlement_status "
            f"{settlement_status!r}."
        )

    currency = (row.get("currency") or "").strip().upper()
    origin_currency = (
        (row.get("origin_currency") or "").strip().upper()
    )
    destination_currency = (
        (row.get("destination_currency") or "").strip().upper()
    )

    if not all((currency, origin_currency, destination_currency)):
        raise ValueError(
            f"{transaction_id}: currency fields are required."
        )

    original_amount = parse_csv_decimal(
        row.get("original_amount"), "original_amount"
    )

    if original_amount < 0:
        raise ValueError(
            f"{transaction_id}: original_amount cannot be negative."
        )

    fx_rate = parse_csv_decimal(row.get("fx_rate"), "fx_rate")

    if fx_rate <= 0:
        raise ValueError(
            f"{transaction_id}: fx_rate must be greater than zero."
        )

    # The dataset defines original_amount in destination_currency.
    # Inflows are denominated in the entity currency.
    # For outflows, origin_currency is the entity currency.
    if direction == "inflow":
        amount = original_amount
        normalized_currency = destination_currency
    else:
        amount = original_amount * fx_rate
        normalized_currency = origin_currency

    return {
        "transaction_id": transaction_id,
        "entity_name": entity_name,
        "region": region,
        "country": country,
        "transaction_date": parse_csv_date(
            row.get("transaction_date(Actual)"),
            "transaction_date(Actual)",
            required=True,
        ),
        "due_date": parse_csv_date(
            row.get("due_date(expected)"),
            "due_date(expected)",
        ),
        "amount": amount,
        "currency": normalized_currency,
        "account_currency": (row.get("currency") or "").strip().upper(),
        "direction": direction,
        "settlement_status": settlement_status,
        "original_amount": original_amount,
        "origin_currency": origin_currency,
        "destination_currency": destination_currency,
        "fx_rate": fx_rate,
        "account_number": (
            row.get("account_number") or ""
        ).strip(),
    }


COUNTRY_ALIASES = {
    "HK": "Hong Kong",
    "Hong Kong": "Hong Kong",
}


def import_csv_dataset(file_path, dry_run=True):
    """
    Validate and import CSV transactions.

    dry_run=True validates the entire file without saving database changes.
    Existing records are preserved. Duplicate transaction IDs are skipped.
    """
    stats = {
        "rows_read": 0,
        "valid_rows": 0,
        "new_transactions": 0,
        "duplicate_transactions": 0,
        "entities_created": 0,
        "accounts_created": 0,
    }

    # First pass: validate all rows before writing anything.
    with open(file_path, newline="", encoding="utf-8-sig") as csv_file:
        reader = csv.DictReader(csv_file)
        validate_csv_headers(reader.fieldnames)

        for line_number, row in enumerate(reader, start=2):
            stats["rows_read"] += 1
            try:
                normalize_transaction(row)
            except (ValueError, TypeError) as exc:
                raise ValueError(f"CSV line {line_number}: {exc}") from exc

            stats["valid_rows"] += 1

    if dry_run:
        return stats

    with transaction.atomic():
        with open(file_path, newline="", encoding="utf-8-sig") as csv_file:
            reader = csv.DictReader(csv_file)

            for row in reader:
                data = normalize_transaction(row)
                country = COUNTRY_ALIASES.get(
                    data["country"], data["country"]
                )

                entity, created = Entity.objects.get_or_create(
                    name=data["entity_name"],
                    defaults={
                        "region": data["region"],
                        "country": country,
                    },
                )
                if created:
                    stats["entities_created"] += 1

                # Refuse to silently change existing entity metadata.
                elif (
                    entity.region != data["region"]
                    or entity.country != country
                ):
                    raise ValueError(
                        f"Entity metadata mismatch for {entity.name}"
                    )

                account, account_created = BankAccount.objects.get_or_create(
                entity=entity,
                account_number=data["account_number"],
                defaults={"currency": data["account_currency"]},
                )

                if not account_created and account.currency != data["account_currency"]:
                    raise ValueError(
                    f"Account currency mismatch for {data['account_number']}"
                )

                if account_created:
                    stats["accounts_created"] += 1

                existing = Transaction.objects.filter(
                    transaction_id=data["transaction_id"]
                ).first()

                if existing:
                    stats["duplicate_transactions"] += 1
                    continue

                Transaction.objects.create(
                    transaction_id=data["transaction_id"],
                    entity=entity,
                    transaction_date=data["transaction_date"],
                    due_date=data["due_date"],
                    amount=data["amount"],
                    currency=data["currency"],
                    direction=data["direction"],
                    settlement_status=data["settlement_status"],
                    original_amount=data["original_amount"],
                    origin_currency=data["origin_currency"],
                    destination_currency=data["destination_currency"],
                    fx_rate=data["fx_rate"],
                )
                stats["new_transactions"] += 1

    return stats


from decimal import Decimal
from django.db import transaction
from django.db.models import Sum
from collections import defaultdict

from .models import CashPosition, Transaction


def rebuild_cash_positions():
    """
    Rebuild daily cash flows from settled transactions only.

    closing_balance stores cumulative net movement from the first
    available transaction date, not a verified bank balance.
    """
    daily_flows = (
        Transaction.objects
        .filter(settlement_status="settled")
        .values("entity_id", "transaction_date", "currency")
        
    .annotate(
        inflow=Sum("amount", filter=Q(direction="inflow")),
        outflow=Sum("amount", filter=Q(direction="outflow")),
    )

        .order_by("entity_id", "currency", "transaction_date")
    )

    running_totals = defaultdict(lambda: Decimal("0"))
    positions = []

    for flow in daily_flows:
        key = (flow["entity_id"], flow["currency"])
        inflow = flow["inflow"] or Decimal("0")
        outflow = flow["outflow"] or Decimal("0")
        net_flow = inflow - outflow
        running_totals[key] += net_flow

        positions.append(
            CashPosition(
                entity_id=flow["entity_id"],
                date=flow["transaction_date"],
                currency=flow["currency"],
                closing_balance=running_totals[key],
                cash_flow=net_flow,
                daily_inflow=inflow,
                daily_outflow=outflow,
                net_flow=net_flow,
            )
        )

    with transaction.atomic():
        CashPosition.objects.all().delete()
        CashPosition.objects.bulk_create(positions, batch_size=1000)

    return {
        "positions_created": len(positions),
        "settled_transactions_used": Transaction.objects.filter(
            settlement_status="settled"
        ).count(),
    }
