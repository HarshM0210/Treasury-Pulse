
from rest_framework.routers import DefaultRouter
from .permissions import IsTreasuryUser, CanManageTreasuryData
from .views import dashboard_summary


from .views import (
    EntityViewSet,
    BankAccountViewSet,
    TransactionViewSet,
    CashPositionViewSet,
    LiquidityThresholdViewSet,
    AdminLiquidityThresholdViewSet,
    ForecastViewSet,
    AlertViewSet,
    ScenarioViewSet,
    ScenarioResultViewSet,
)

router = DefaultRouter()

router.register("entities", EntityViewSet)
router.register("bank-accounts", BankAccountViewSet)
router.register("transactions", TransactionViewSet)
router.register("cash-positions", CashPositionViewSet)
router.register("liquidity-thresholds", LiquidityThresholdViewSet)
router.register(
    "admin-liquidity-thresholds",
    AdminLiquidityThresholdViewSet,
    basename="admin-liquidity-threshold",
)
router.register("forecasts", ForecastViewSet)
router.register("alerts", AlertViewSet)
router.register("scenarios", ScenarioViewSet)
router.register("scenario-results", ScenarioResultViewSet)

from django.urls import path

urlpatterns = [
    path("dashboard/", dashboard_summary, name="dashboard-summary"),
] + router.urls
