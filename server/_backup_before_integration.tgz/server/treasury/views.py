from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from .permissions import IsTreasuryUser, CanManageTreasuryData
from rest_framework import viewsets
from django.db.models import OuterRef, Subquery, Sum, Max
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes

from datetime import timedelta
from decimal import Decimal

from django.utils import timezone
from rest_framework.decorators import action
from rest_framework.response import Response

from django.db import transaction

from .models import LiquidityThreshold

from .models import (
    Entity,
    BankAccount,
    Transaction,
    CashPosition,
    LiquidityThreshold,
    Forecast,
    Alert,
    Scenario,
    ScenarioResult,
)
from .serializers import (
    EntitySerializer,
    BankAccountSerializer,
    TransactionSerializer,
    CashPositionSerializer,
    LiquidityThresholdSerializer,
    ForecastSerializer,
    ForecastInputSerializer,
    AlertSerializer,
    ScenarioSerializer,
    ScenarioResultSerializer,
)
from .permissions import IsTreasuryUser
from .scoping import get_allowed_entities


class ReadOnlyTreasuryViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsTreasuryUser]
    entity_lookup = "entity"

    def get_queryset(self):
        queryset = super().get_queryset()
        allowed_entities = get_allowed_entities(self.request.user)

        if self.entity_lookup == "__self__":
            return queryset.filter(
                pk__in=allowed_entities.values("pk")
            )

        return queryset.filter(
            **{f"{self.entity_lookup}__in": allowed_entities}
        )


class EntityViewSet(ReadOnlyTreasuryViewSet):
    queryset = Entity.objects.all()
    serializer_class = EntitySerializer
    entity_lookup = "__self__"


class BankAccountViewSet(ReadOnlyTreasuryViewSet):
    queryset = BankAccount.objects.all()
    serializer_class = BankAccountSerializer


class TransactionViewSet(ReadOnlyTreasuryViewSet):
    queryset = Transaction.objects.all()
    serializer_class = TransactionSerializer


class CashPositionViewSet(ReadOnlyTreasuryViewSet):
    queryset = CashPosition.objects.all()
    serializer_class = CashPositionSerializer


class LiquidityThresholdViewSet(ReadOnlyTreasuryViewSet):
    queryset = LiquidityThreshold.objects.all()
    serializer_class = LiquidityThresholdSerializer


class AdminLiquidityThresholdViewSet(viewsets.ModelViewSet):
    queryset = LiquidityThreshold.objects.all()
    serializer_class = LiquidityThresholdSerializer
    permission_classes = [CanManageTreasuryData]

    def get_queryset(self):
        queryset = super().get_queryset()
        allowed_entities = get_allowed_entities(self.request.user)
        return queryset.filter(entity__in=allowed_entities)




class ForecastViewSet(ReadOnlyTreasuryViewSet):
    queryset = Forecast.objects.all()
    serializer_class = ForecastSerializer

    @action(detail=False, methods=["post"], url_path="store")
    def store(self, request):
        serializer = ForecastInputSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        entity = serializer.validated_data["entity"]
        allowed_entities = get_allowed_entities(request.user)

        if not allowed_entities.filter(id=entity.id).exists():
            return Response(
                {"detail": "You do not have access to this entity."},
                status=status.HTTP_403_FORBIDDEN,
            )

        forecast, created = Forecast.objects.update_or_create(
            entity=entity,
            currency=serializer.validated_data["currency"],
            forecast_date=serializer.validated_data["forecast_date"],
            defaults={
                key: value
                for key, value in serializer.validated_data.items()
                if key != "entity"
            },
        )

        return Response(
            ForecastSerializer(forecast).data,
            status=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
        )


    @action(detail=False, methods=["post"])
    def generate(self, request):
        allowed_entities = get_allowed_entities(request.user)

        latest_positions = CashPosition.objects.filter(
            entity__in=allowed_entities
        ).order_by("entity_id", "currency", "-date")

        # Keep the latest position for each entity and currency.
        latest_by_key = {}
        for position in latest_positions:
            key = (position.entity_id, position.currency)
            if key not in latest_by_key:
                latest_by_key[key] = position

        generated = []
        run_id = timezone.now().strftime("%Y%m%d%H%M%S")

        for (entity_id, currency), position in latest_by_key.items():
            threshold = LiquidityThreshold.objects.filter(
                entity_id=entity_id,
                currency=currency,
            ).first()

            daily_net_flow = position.net_flow or Decimal("0")

            for day in range(1, 8):
                forecast_date = position.date + timedelta(days=day)
                predicted_balance = (
                    position.closing_balance + daily_net_flow * day
                )

                minimum_balance = (
                    threshold.minimum_balance if threshold else None
                )
                liquidity_gap = (
                    max(Decimal("0"), minimum_balance - predicted_balance)
                    if minimum_balance is not None
                    else None
                )

                risk_level = (
                    "HIGH" if liquidity_gap and liquidity_gap > 0
                    else "LOW" if minimum_balance is not None
                    else "UNKNOWN"
                )

                forecast, _ = Forecast.objects.update_or_create(
                    entity_id=entity_id,
                    currency=currency,
                    forecast_date=forecast_date,
                    defaults={
                        "predicted_balance": predicted_balance,
                        "forecast_run_id": run_id,
                        "lower_bound": None,
                        "upper_bound": None,
                        "scheduled_net": None,
                        "predicted_net": daily_net_flow,
                        "liquidity_gap": liquidity_gap,
                        "risk_level": risk_level,
                    },
                )
                
                generated.append(forecast)

                
                if liquidity_gap is not None and liquidity_gap > 0:
                    existing_alert = Alert.objects.filter(
                        entity_id=entity_id,
                        severity="HIGH",
                        status="OPEN",
                    ).first()

                    if existing_alert:
                        if liquidity_gap > existing_alert.liquidity_gap:
                            existing_alert.liquidity_gap = liquidity_gap
                            existing_alert.save(
                                update_fields=["liquidity_gap"]
                            )
                    else:
                        Alert.objects.create(
                            entity_id=entity_id,
                            severity="HIGH",
                            liquidity_gap=liquidity_gap,
                            status="OPEN",
                        )



        return Response({
            "message": "Forecast generation completed.",
            "forecast_run_id": run_id,
            "forecasts_generated": len(generated),
        })




class AlertViewSet(ReadOnlyTreasuryViewSet):
    queryset = Alert.objects.all()
    serializer_class = AlertSerializer

    @action(detail=True, methods=["post"])
    def acknowledge(self, request, pk=None):
        alert = self.get_object()
        alert.status = "ACKNOWLEDGED"
        alert.save(update_fields=["status"])

        return Response({
            "message": "Alert acknowledged successfully.",
            "alert_id": alert.id,
            "status": alert.status,
        })

    @action(detail=True, methods=["post"])
    def resolve(self, request, pk=None):
        alert = self.get_object()
        alert.status = "RESOLVED"
        alert.save(update_fields=["status"])

        return Response({
            "message": "Alert resolved successfully.",
            "alert_id": alert.id,
            "status": alert.status,
        })



class ScenarioViewSet(ReadOnlyTreasuryViewSet):
    queryset = Scenario.objects.all()
    serializer_class = ScenarioSerializer


class ScenarioResultViewSet(ReadOnlyTreasuryViewSet):
    queryset = ScenarioResult.objects.all()
    serializer_class = ScenarioResultSerializer
    entity_lookup = "scenario__entity"


@api_view(["GET"])
@permission_classes([IsAuthenticated, IsTreasuryUser])
def dashboard_summary(request):
    allowed_entities = get_allowed_entities(request.user)

    latest_position_date = (
        CashPosition.objects
        .filter(
            entity_id=OuterRef("entity_id"),
            currency=OuterRef("currency"),
        )
        .order_by("-date")
        .values("date")[:1]
    )

    positions = CashPosition.objects.filter(
        entity__in=allowed_entities,
        date=Subquery(latest_position_date),
    )

    latest_date = positions.aggregate(
        latest_date=Max("date")
    )["latest_date"]

    currency_totals = positions.values("currency").annotate(
        closing_balance=Sum("closing_balance"),
        daily_inflow=Sum("daily_inflow"),
        daily_outflow=Sum("daily_outflow"),
        net_flow=Sum("net_flow"),
    ).order_by("currency")

    open_alert_count = Alert.objects.filter(
        entity__in=allowed_entities,
        status="OPEN",
    ).count()

    entity_positions = positions.values(
        "entity_id",
        "entity__name",
        "currency",
        "date",
    ).annotate(
        closing_balance=Sum("closing_balance"),
        daily_inflow=Sum("daily_inflow"),
        daily_outflow=Sum("daily_outflow"),
        net_flow=Sum("net_flow"),
    ).order_by("entity__name", "currency")

    return Response({
        "as_of": latest_date,
        "currency_totals": list(currency_totals),
        "open_alert_count": open_alert_count,
        "entity_positions": list(entity_positions),
    })
